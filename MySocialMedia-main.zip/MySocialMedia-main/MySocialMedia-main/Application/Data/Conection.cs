﻿using Google.Cloud.Firestore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Data
{
    public class Conection
    {
        public FirestoreDb FirestoreDb { get; set; }
        public Conection() {
            var filePath = @"Data\mysocialmedia-f8df6-firebase-adminsdk-fnl8d-60f179c360.json";
            Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", filePath);
            FirestoreDb = FirestoreDb.Create("mysocialmedia-f8df6");
        }
    }
}
