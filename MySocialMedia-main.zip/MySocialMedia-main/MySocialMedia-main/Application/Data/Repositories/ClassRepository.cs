﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Data.Repositories
{
    public class ClassRepository //: IRepository<Ubicacion>   
    {
        //private const string COLLECTION_NAME = "clase";
        //private readonly Connection_conne
        //public void Delete(string id)
        //{
        //    throw new NotImplementedException();
        //}
        //public List<Ubicacion> FindAll() {
        //    throw new NotImplementedException();
        //}
        //public Ubicacion FindById(string id)
        //{ 
        //    throw new NotImplementedException();
        //}
        //public void Insert(ClassRepository entity)
        //{
        //    throw new NotImplementedException();
        //}
        //public Ubicacion Update(Ubicacion entity)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
