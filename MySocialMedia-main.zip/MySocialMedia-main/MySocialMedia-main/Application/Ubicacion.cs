﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application
{
    public class Ubicacion
    {
        private double Latitud;
        private double Longitud;

        public Ubicacion(double latitud, double longitud)
        {
            Latitud = latitud;
            Longitud = longitud;
        }
        public double Latitude
        {
            get { return Latitud; }
            set { Latitud = value; }
        }
        public double Longitude
        {
            get { return Longitud; }
            set { Longitud = value; }
        }

    }
}
