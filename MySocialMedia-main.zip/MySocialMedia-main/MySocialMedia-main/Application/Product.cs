﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application
{
    public class Product
    {
        private string Name;
        private double Cost;
        private string Category;
        private Ubicacion Coordenadas;

        public Product(string nombre, double precio, string category, double latitud, double longitud)
        {
            NameProduct = nombre;
            CostProduct = precio;
            Category = category;
           Coordenadas= new Ubicacion(latitud, longitud);
        }

        public string NameProduct
        {
            get { return Name; }
            set { Name = value; }
        }
        public double CostProduct
        {
            get { return Cost; }
            set { Cost = value; }
        }
        public string productCategory
        {
            get { return Category; }
            set { Category = value; }
        }
        public Ubicacion coordinates
        {
            get { return Coordenadas; }
            set { Coordenadas = value; }
        }
    }
}
